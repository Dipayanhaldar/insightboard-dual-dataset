# InsightBoard — Schema-aware dashboard

A React + Vite dashboard for exploring a single active dataset at a time. JSON/CSV imports replace the active dataset; imported fields drive filters, KPI summaries, chart labels and table columns. Responsive import controls remain visible on mobile.

## Run locally
1. Install Node.js LTS.
2. In this folder, run `npm install`.
3. Run `npm run dev` and open the local URL printed by Vite.
4. Run `npm run build` to verify a production build.

## Supported data shapes
- JSON array of objects: `[{"station":"A","line":"Blue","platforms":2}]`
- JSON object with `records` array: `{ "records": [...] }`
- JSON object with `data` array: `{ "data": [...] }`
- CSV with a header row and at least one data row.

The dashboard detects fields in the imported records. Numeric fields drive metric summaries; categorical fields drive filters and grouping. The first 12 fields appear in the table and up to 8 categorical fields become filters. Data is demo/reference data unless independently verified.

## Vercel
Import this repository into Vercel with Root Directory `.` (repository root), Build Command `npm run build`, and Output Directory `dist`. Install Command can remain automatic (`npm install`).


## Export options
- Export CSV downloads the currently filtered records as CSV.
- Export Excel downloads an `.xlsx` workbook with a Filtered Data sheet and Report Info sheet.
- PDF + 6 Charts generates a PDF using the currently rendered chart panels and includes a data table. The PDF table is capped at 1,000 rows and 12 columns for readability; use Excel for complete wide/large datasets.

This update does not add an AI/Gemini button. A secure AI conversion feature needs an explicit provider, API key handling, supported file parsing, privacy controls, and likely a server-side endpoint; exposing an API key in a public frontend would be unsafe.
